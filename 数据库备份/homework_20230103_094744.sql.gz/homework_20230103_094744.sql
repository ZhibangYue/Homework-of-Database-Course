-- MySQL dump 10.13  Distrib 5.7.39, for Linux (x86_64)
--
-- Host: localhost    Database: homework
-- ------------------------------------------------------
-- Server version	5.7.39-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `name` (`name`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group_permissions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`) USING BTREE,
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`) USING BTREE,
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`) USING BTREE,
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can view log entry',1,'view_logentry'),(5,'Can add permission',2,'add_permission'),(6,'Can change permission',2,'change_permission'),(7,'Can delete permission',2,'delete_permission'),(8,'Can view permission',2,'view_permission'),(9,'Can add group',3,'add_group'),(10,'Can change group',3,'change_group'),(11,'Can delete group',3,'delete_group'),(12,'Can view group',3,'view_group'),(13,'Can add user',4,'add_user'),(14,'Can change user',4,'change_user'),(15,'Can delete user',4,'delete_user'),(16,'Can view user',4,'view_user'),(17,'Can add content type',5,'add_contenttype'),(18,'Can change content type',5,'change_contenttype'),(19,'Can delete content type',5,'delete_contenttype'),(20,'Can view content type',5,'view_contenttype'),(21,'Can add session',6,'add_session'),(22,'Can change session',6,'change_session'),(23,'Can delete session',6,'delete_session'),(24,'Can view session',6,'view_session'),(25,'Can add books',7,'add_books'),(26,'Can change books',7,'change_books'),(27,'Can delete books',7,'delete_books'),(28,'Can view books',7,'view_books'),(29,'Can add admin_ users',8,'add_admin_users'),(30,'Can change admin_ users',8,'change_admin_users'),(31,'Can delete admin_ users',8,'delete_admin_users'),(32,'Can view admin_ users',8,'view_admin_users'),(33,'Can add users',9,'add_users'),(34,'Can change users',9,'change_users'),(35,'Can delete users',9,'delete_users'),(36,'Can view users',9,'view_users'),(37,'Can add types',10,'add_types'),(38,'Can change types',10,'change_types'),(39,'Can delete types',10,'delete_types'),(40,'Can view types',10,'view_types');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `username` (`username`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user`
--

LOCK TABLES `auth_user` WRITE;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
INSERT INTO `auth_user` VALUES (1,'pbkdf2_sha256$390000$6bj9tuGy2kiq2kfIhcEew8$bwjW/ke66rttrT34GFyxZYBxk5dwWWCj3t5W7aJ6Xco=','2022-12-12 14:43:51.218599',1,'admin','','','',1,1,'2022-12-11 14:56:27.349912');
/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_groups`
--

DROP TABLE IF EXISTS `auth_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_groups` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`) USING BTREE,
  KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`) USING BTREE,
  CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_groups`
--

LOCK TABLES `auth_user_groups` WRITE;
/*!40000 ALTER TABLE `auth_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_user_permissions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`) USING BTREE,
  KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`) USING BTREE,
  CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_user_permissions`
--

LOCK TABLES `auth_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `auth_user_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`) USING BTREE,
  KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`) USING BTREE,
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
INSERT INTO `django_admin_log` VALUES (1,'2022-12-12 05:43:52.507028','1','Admin_Users object (1)',1,'[{\"added\": {}}]',8,1),(2,'2022-12-12 09:39:12.648848','2','Admin_Users object (2)',1,'[{\"added\": {}}]',8,1);
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (1,'admin','logentry'),(3,'auth','group'),(2,'auth','permission'),(4,'auth','user'),(5,'contenttypes','contenttype'),(8,'myadmin','admin_users'),(7,'myadmin','books'),(10,'myadmin','types'),(9,'mylib','users'),(6,'sessions','session');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_migrations` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2022-12-11 14:54:52.516373'),(2,'auth','0001_initial','2022-12-11 14:54:53.018256'),(3,'admin','0001_initial','2022-12-11 14:54:53.145160'),(4,'admin','0002_logentry_remove_auto_add','2022-12-11 14:54:53.155154'),(5,'admin','0003_logentry_add_action_flag_choices','2022-12-11 14:54:53.165310'),(6,'contenttypes','0002_remove_content_type_name','2022-12-11 14:54:53.275814'),(7,'auth','0002_alter_permission_name_max_length','2022-12-11 14:54:53.341279'),(8,'auth','0003_alter_user_email_max_length','2022-12-11 14:54:53.385703'),(9,'auth','0004_alter_user_username_opts','2022-12-11 14:54:53.400661'),(10,'auth','0005_alter_user_last_login_null','2022-12-11 14:54:53.486814'),(11,'auth','0006_require_contenttypes_0002','2022-12-11 14:54:53.490802'),(12,'auth','0007_alter_validators_add_error_messages','2022-12-11 14:54:53.502770'),(13,'auth','0008_alter_user_username_max_length','2022-12-11 14:54:53.577664'),(14,'auth','0009_alter_user_last_name_max_length','2022-12-11 14:54:53.660674'),(15,'auth','0010_alter_group_name_max_length','2022-12-11 14:54:53.692890'),(16,'auth','0011_update_proxy_permissions','2022-12-11 14:54:53.708810'),(17,'auth','0012_alter_user_first_name_max_length','2022-12-11 14:54:53.796013'),(19,'sessions','0001_initial','2022-12-11 14:54:53.863466'),(22,'mylib','0001_initial','2022-12-12 14:42:51.547612'),(23,'myadmin','0001_initial','2022-12-13 03:44:33.533351'),(24,'myadmin','0002_types','2022-12-13 03:44:33.608003');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`) USING BTREE,
  KEY `django_session_expire_date_a5c62663` (`expire_date`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('08pebeq7e7gvkljjx2tek2y4b96v2ela','.eJxVjDsOwjAQBe_iGln-xgslPWew1usFB5AtxUmFuDtYSgHtzLz3EhG3tcSt8xLnLE5Ci8MvS0gPrkPkO9Zbk9TqusxJjkTutstLy_w87-3fQcFevmulVDDkGXUAthNkZyikbJX3kzeYGCEMzkCJUGcgAqCju3JybI0X7w_alzg1:1p4Nkq:0ArBcgmvFX4ORRGdTDxoRZkAp3Fot933AKYtRiiUvL8','2022-12-25 14:56:36.618978'),('5y9d6rhrf51byl6hg5kl9yfbtpofu5m3','.eJwVjTsOwjAQRO-ydURYBX9wxyGgcuP4I1aQNXLiNFHujt1M8eaN5oA9Fkrkc4hgQOJLwQCPsBA_11jAHEABDA7A5D_slm7ZKsNttlXPQdgqpqSwjX7vzL1FrcSEd6mvstOSE307H9fNbeTH5PZ2x5cWcJ5_GDsoFw:1p7UZl:QrH_eLLdlGxGqCnm_EWWwExYsdmiHvZbfECo_791mxo','2023-01-03 04:50:01.026553'),('628nk1efxlw3c3zpn49bqurptwmjrcq5','.eJyrVipLLcpMy0zOT0lVslLyjHB0VdJRckzJzcwLLU4tUrKqVspMUbIy1FHKy0zOzkvMBamKKTVJTTWOKbWwMLMAqi7IyM8DCRtamJsaG1qaWRiYgUSL8tMyc0Di-sUliSWZyfppiWVAe_L0gIRSbS0ADYol7w:1p4fjp:Ly0teSceLLYsE2LN3glp7IlNdT-J-R496cQnRdAiNl0','2022-12-26 10:08:45.436147'),('as3z231f08f3eqdcmgolhtz22tkvx7fg','eyJ2ZXJpZmljb2RlIjoiWjVVViJ9:1p5HJH:DUgzwic9yzVPruqZ7C8RMbOGrkBrwYsRRw265Bq2TJY','2022-12-28 02:15:51.067011'),('awb657yswel7fzx9i0g7yp9hvim0ajlw','.eJyrVipLLcpMy0zOT0lVslKy9Ah3UdJRckzJzcwLLU4tUrKqVspMUbIy1FHKy0zOzkvMBamKKTVLMUmKKbVISjGNKTU1TjM3BGoqyMjPA8kaWpibGhtamlkYmIFEi_LTMnNA4vrFJYklmcn6aYllQOvy9ICEUm0tACnLKD8:1p7UcP:ebQIwQjA08IJsQ6lcg57WvO3UqO32Bl-Pu-jOVvfaJA','2023-01-03 04:52:45.243424'),('bzm69r0ntfwt9sl3xv2pzs1pzb60zan5','eyJ2ZXJpZmljb2RlIjoiVkJNWSJ9:1p5gE2:YdrUYAwfy205nzl5Vhced-xlI6yAic0tyrdLPiDFw_E','2022-12-29 04:52:06.409771'),('ceiztehim8e5i32jehv1yqaf95h38ln8','eyJ2ZXJpZmljb2RlIjoiNUZZRyJ9:1p5Up9:t4hvqU-Izs5DGeL5l4oDTdD5Fgtcrfk-65phnQmPlg0','2022-12-28 16:41:39.245519'),('db57ndwcdilyydhquw4zzgc3sitiq0vv','eyJ2ZXJpZmljb2RlIjoiWjhJUyJ9:1p7UcZ:bAKkzvH5Aj8-IIN-6K0WEVl7_UPaaSAt0G4sSb_uOb8','2023-01-03 04:52:55.324456'),('ei64xphs91y3rh93djvbap2vehh7ujqi','eyJ2ZXJpZmljb2RlIjoiNVNSWCJ9:1p5gGF:dNpsg0EyxbgKoBBZuObqoq9kw2IgYA49s2GBFa0whTo','2022-12-29 04:54:23.398538'),('eu4ax2pcbyvprjkqq3itqcvmba3pznjn','.eJyVjssOgjAQRf9l1gQs2IKs8BMMccem9CETaWuAkijh321XujPO4i7OzM2ZDVY1oUbhpIIaWtpeIIGzNGivs5qg3gAl1CQBi-JuuYlXnWfy2He-6iXtPC10SULpMTgbt6QqaUFOrDqwSCencYw8mxe-oMg0X4POpiFgT-Bbk_-j-UygynAcA3169Rqw5_bWkJylwpnfP-xvDylQ9g:1p8fOM:lNUoaHJKkJQzOdie6fMRWM_V8U5MDWcB2ej92v2OhpY','2023-01-06 10:35:06.069508'),('gzo4droes2xpvp0turiady6l5gowvtxu','eyJ2ZXJpZmljb2RlIjoiQVE2MSJ9:1p7Ucw:pQuO88PVuJ6QEKHTc--pREcWkwAW_3_YWmvPsFmF9kA','2023-01-03 04:53:18.793485'),('mqcsl7hs7a506lfectg1y015w7a9w6mz','.eJwVjcEOwiAQRP9lz42VVChyU7_BgwkXykLcaBdDSy9N_124zOHNm8wOW8gUyScMYOChXnfo4IYz8XMJGcwOhGBEB0z-w25uli0KL5MtekJpixziKOro907cWqFHOYir0mfVaE6Rvo33y-pW8n10W73jUw04jj8mTyg3:1p5gG0:V0PvDABXZKdsnlKj_yb9n0HaJhx4hWBPI7yieg-uIfk','2022-12-29 04:54:08.753614'),('odp5zsc8l22m7nrqw8gep78aa3gp0uzq','eyJ2ZXJpZmljb2RlIjoiOFo1TiJ9:1p5Sm1:egJRESV63JKeLcFF-DaZ0M3qGcBJ8ZbrBpAgf5j7rCw','2022-12-28 14:30:17.631406'),('qmp2zo9muxorhxedkl7wiewxw8evh1uq','eyJ2ZXJpZmljb2RlIjoiSThOQyJ9:1p7UXc:c_3ATRb47VQszc82aTylopdYZgO1h-7L-n4jARZoQCQ','2023-01-03 04:47:48.032710'),('vuio408961pkhv3uwqpwtsbwkrk9rtj5','eyJ2ZXJpZmljb2RlIjoiQjNCMyJ9:1p5gHM:aM4tPtuxir10gNHXz2iyIcL15Lp61wDDNH9MPTN-vDE','2022-12-29 04:55:32.970034'),('wxj8i13fesb9w0wzazus30dc4qldlkso','.eJy1jT0OAiEUBu_y1cSVoIh0JpbGzm4bAo_4ogsb9qfZ7N2FQ9hMMZlkNqxUOLLPgWDxUPcnBF4TFdgNHGClQGL_SW5oQb-ciFS_GKNNDcd3Tk1LczkredXmqJstOfK3-W6a3cy-i26ti3SowC5wCwOn_072H0zpQt0:1p5QvG:0tfPw64clZMo9MafrI4iFM39hzV8XRFkYhW3GwrdkLA','2022-12-28 12:31:42.017670'),('x6za5kkal39tlc39agbiux13lci31c3z','.eJyrVipLLcpMy0zOT0lVslJyiQgLUNJRckzJzcwLLU4tUrKqVspMUbIy1FHKy0zOzkvMBamKKTVJTTWOKbWwMLMAqi7IyM8DCRtamJsaG1qaWRiYgUSL8tMyc0Di-sUliSWZyfppiWVAe_L0gIRSbS0AGIgmCg:1p4ilo:zNOlaHtR3Ho0Og4t3QA4n5HmehILFktK1JOZt3ZGxuw','2022-12-26 13:23:00.855269');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `myadmin_admin_users`
--

DROP TABLE IF EXISTS `myadmin_admin_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `myadmin_admin_users` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nickname` varchar(20) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `profile` varchar(100) NOT NULL,
  `sex` varchar(1) DEFAULT NULL,
  `registerdate` date NOT NULL,
  `password` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `myadmin_admin_users`
--

LOCK TABLES `myadmin_admin_users` WRITE;
/*!40000 ALTER TABLE `myadmin_admin_users` DISABLE KEYS */;
INSERT INTO `myadmin_admin_users` VALUES (1,'测试号1','18753196806','/static/favicon.ico','1','2022-12-12','pbkdf2_sha256$390000$67KPUTBVfjua9tADGki16U$/3c639yC7eSHBIpg/TkC4uWntKtFuHoYGa22y9X4fBY=');
/*!40000 ALTER TABLE `myadmin_admin_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `myadmin_books`
--

DROP TABLE IF EXISTS `myadmin_books`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `myadmin_books` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `author` varchar(50) NOT NULL,
  `pic` varchar(150) NOT NULL,
  `pub_date` date NOT NULL,
  `price` double NOT NULL,
  `publisher` varchar(100) NOT NULL,
  `abstract` longtext NOT NULL,
  `type` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `myadmin_books`
--

LOCK TABLES `myadmin_books` WRITE;
/*!40000 ALTER TABLE `myadmin_books` DISABLE KEYS */;
INSERT INTO `myadmin_books` VALUES (1,'鸭子的故事2','岳志邦','/static/favicon.ico','2022-12-11',0.88,'鸭子出版社','','文学'),(2,'鸭子的故事','岳志邦','/static/favicon.ico','2022-12-11',25,'鸭子出版社','鸭子的故事鸭','文学'),(3,'鸭子的故事4','岳志邦','/static/uploads/1670825835.4774547.jpg','2022-12-12',0,'鸭子出版社','嘎嘎嘎','文学'),(4,'C程序设计','谭浩强','/static/uploads/1671010328.1422653.jpg','2017-09-01',59.9,'清华大学出版社','由谭浩强教授著、清华大学出版社出版的《C程序设计》经过近三十年一千多万读者的实践检验，被公认为学习C语言程序设计的经典教材。根据C语言的发展和计算机教学的需要，作者在《C程序设计(第四版)》的基础上进行了修订，使内容更加完善，更易于理解，更加切合教学需要。本书按照C语言的新标准C 99进行介绍，所有程序都符合C 99的规定，使编写程序更加规范；对C语言和程序设计的基本概念和要点讲解透彻、全面而深入；按照作者提出的“提出问题—解决问题—归纳分析”三部曲进行教学和组织教材；本书的每个例题都按以下几个步骤展开：提出任务—解题思路—编写程序—运行程序—程序分析—有关说明。符合读者认知规律，容易入门与提高。 本书内容先进，体系合理，概念清晰，讲解详尽，降低台阶，分散难点，例题丰富，深入浅出，文字流畅，通俗易懂，是初学者学习C语言程序设计的理想教材，既可作为高等学校各专业的正式教材，也适合读者自学。本书还配有辅助教材《C程序设计(第五版）学习辅导》。','信息学'),(5,'线性代数','刘建亚、吴臻','/static/uploads/1671017667.3692195.jpg','2010-06-01',29.9,'高等教育出版社','《大学数学教程：线性代数（第3版）》根据高等学校非数学类专业线性代数课程的教学要求和教学大纲，在吸收国内外优秀教材的优点并结合多年教学经验的基础上编写而成。主要内容包括矩阵、n维向量、线性方程组、矩阵的特征值与特征向量、二次型，本次修订增加了少量思考题，以加深读者对学习内容的理解，《大学数学教程：线性代数（第3版）》兼顾不同专业、不同学时的需要，适当安排了一些选学章节，其中，加一个“*”号的内容为对数学要求较高的专业所用，加两个“*”号的内容可供教师选用或学有余力的学生课外阅读，书中每章配有MATLAB运算实例，书末附有思考题参考答案、部分习题参考答案和数学建模应用举例。','理学'),(6,'电路','邱关源、罗先觉','/static/uploads/1670990166.040391.jfif','2006-05-01',59.9,'高等教育出版社','《普通高等教育“十五”规划教材 电路（第5版）》为普通高等教育“十五”规划教材。全书共分8章，主要内容有 电路模型和电路定律、电阻电路的等效变换、电阻电路的一般分析、电路定理、含有运算放大器的电阻电路、储能元件、一阶电路和二阶电路的时域分析、相量法、正弦稳态电路的分析、含有耦合电感的电路、电路的频率响应、三相电路、非正弦周期电流电路和信号的频谱、线性动态电路的复频域分析、电路方程的矩阵形式、二端口网络、非线性电路、均匀传输线，另有磁路和铁心线圈、PSpice 简介和MATLAB简介三个附录。书末附有部分习题答案。《普通高等教育“十五”规划教材 电路（第5版）》可供高等学校电子与电气信息类专业师生作为电路课程的教材使用，也可供有关科技人员参考。','工学'),(7,'工程图学基础','刘宇红、张建军','/static/uploads/1671018010.2902548.jpg','2010-10-01',52,'机械工业出版社','本书为“十二五” 普通高等教育本科规划教材､普通高等教育“十一五” 规划教材, 是根据我国当前对高素质､高水平､国际化人才的需求, 在总结和吸取多年教学改革经验的基础上并参考国内外同类教材编写而成的｡本书根据本学科知识的逻辑性､系统性､规律性, 在不同阶段､不同环节中, 对学生进行不同程度的空间思维能力､构形能力､创新能力和解决复杂工程问题能力的培养｡本书的主要特点是: 采用了现行的国家标准, 建立了独特的结构体系, 在第2 版的基础上增加了工程应用内容, 适用性强｡本书的主要内容有: 绪论, 点､直线､平面的投影, 立体的投影, 制图的基本知识, 组合体, 轴测图, 图样画法, 标准件及常用件, 零件图,装配图, 其他常用工程图简介｡','工学'),(8,'复变函数与积分变换','刘建亚、吴臻','/static/uploads/1671014652.2674.jpg','2016-12-01',32,'高等教育出版社','本书是山东大学数学学院编写的《大学数学教程》系列教材中的一本（全套教材包括《微积分1》《微积分2》《线性代数》《概率论与数理统计》《复变函数与积分变换》共5册），由首届高等学校教学名师奖获得者、长江学者刘建亚教授主持，山东大学数学学院一线教师编写。本次修订在保持上一版原有特色的基础上，新版更加注重与中学教学内容的衔接，增选一些国外教材中的题目及近年来的考研题，力求题型更新颖；立足大学通识教育改革理念，进一步加强各知识模块间的有机融合。另外，本次修订增加与纸质教材内容结合的数字资源及思考题，整套教材将做成新形态教材。本书主要内容包括：复数与复变函数、解析函数、复变函数的积分、级数、留数理论及其应用、共形映射、Fourier变换、Laplace变换等','理学'),(9,'数据库应用技术(SQL Server 2008)','石玉芳、卜耀华','/static/uploads/1671093608.6578102.png','2015-12-01',25.4,'清华大学出版社','本书从数据库技术的实际应用出发，以任务驱动、案例教学为主要教学方式，介绍了SQL Server 2008的实用技术，具有概念清晰、系统全面、精讲多练、实用性强和突出技能培训等特点，主要内容包括数据库基础知识、数据库设计、表和视图的创建管理、数据查询、Transact-SQL 语言基础、存储过程和触发器的创建与使用、数据库安全管理、事务与锁的使用以及SQL Server应用开发实例。本书可作为高职高专理工类专业及各类培训学校的数据库相关课程的教材，也可作为企业数据库管理与开发人员的参考书。','信息学'),(10,'数字电子技术基础','臧利林、徐向华、姚福安','/static/uploads/1671099171.305269.jpg','2022-07-01',75,'清华大学出版社','本书借鉴先进教学经验，吸收先进教学成果，优化课程内容结构，注重实用性，并结合信息化教学新模式、新形态编著而成。本书主要讲述数字电子技术理论及其应用，深度剖析原理和方法，并提供了教学大纲、PPT课件、大量动画、视频以及扩展文献作为配套教学资源，方便教师开展线上线下混合式教学。 本书共分10章，内容主要包括数字电路基础、逻辑代数、逻辑门电路、组合逻辑电路、记忆单元电路、时序逻辑电路、脉冲单元电路、半导体存储器、数模与模数转换电路、可编程逻辑器件。本书深入浅出，逻辑严谨，章节自成体系又联系紧密，系统性强。本书要点论述透彻，便于自学，读者可结合本书的配套学习指南与习题解答进行全面、深入的学习。 本书可作为高等学校自动化类、电气自动化类、电子信息类、计算机类、仪器仪表类、机电工程类等专业的教材，也可供其他相关理工科专业选用，还可供有需要的工程技术人员和一般读者阅读。','工学'),(11,'概率论与数理统计','刘建亚、吴臻','/static/uploads/1671125159.8743248.jpg','2020-07-01',33.4,'高等教育出版社','本书是山东大学数学学院编写的《大学数学教程》系列教材中的一本（全套教材包括《微积分1》《微积分2》《线性代数》《概率论与数理统计》《复变函数与积分变换》共5册），由首届高等学校教学名师奖获得者、长江学者刘建亚教授主持，山东大学数学学院一线教师编写。 本次修订在保持上一版原有特色的基础上，新版更加注重与中学教学内容的衔接，增选一些国外教材中的题目及近年来的考研题，力求题型更新颖；立足大学通识教育改革理念，进一步加强各知识模块间的有机融合。另外，本次修订增加与纸质教材内容结合的数字资源及思考题，整套教材将做成新形态教材。 本书主要内容包括：概率论的基本概念、随机变量及其概率分布、数字特征、大数定律与中心极限定理、统计量及其概率分布、参数估计和假设检验、回归分析、方差分析等。','理学'),(12,'大学基础物理学（第3版）上','张三慧、阮东、安宇','/static/uploads/1671103584.8710566.jpg','2017-02-01',51.9,'清华大学出版社','《大学基础物理学》（第3版）分上下两册，上册内容包括力学和热学。力学篇讲述经典的质点力学、理想流体的运动规律、刚体转动的基本内容和狭义相对论基础知识等。热学篇着重在分子论的基础上用统计概念说明温度、气体的压强以及麦克斯韦分布率。下册内容包括电磁学、波动与光学、量子物理基础。电磁学篇按传统体系讲述了电场、电势、磁场、电磁感应和电磁波的基本概念和规律，还说明了电场和磁场的相对性。波动与光学篇介绍了振动与波的基本特征和光的干涉、衍射和偏振的基本规律。量子物理基础篇介绍了波粒二象性、概率波、不确定关系和能量量子化等基本概念以及原子和固体中电子的状态和分布的规律，还介绍了原子核的结合能、放射性衰变和核反应等基本知识。本书还编写了大量来自生活、实用技术以及自然现象等方面的例题和习题。本书上下册内容涵盖了大学物理学教学的基本要求，可作为高等院校物理课程的教材，也可作为中学物理教师或其他读者的自学参考书。与本书配套的《大学基础物理学学习辅导与习题解答（第3版）》、电子教案、教师用书（电子版）均由清华大学出版社出版。 ','理学'),(13,'大学基础物理学（第3版）下','张三慧、阮东、安宇','/static/uploads/1671170037.2950344.jpg','2017-02-01',56,'清华大学出版社','《大学基础物理学》（第3版）分上下两册，上册内容包括力学和热学。力学篇讲述经典的质点力学、理想流体的运动规律、刚体转动的基本内容和狭义相对论基础知识等。热学篇着重在分子论的基础上用统计概念说明温度、气体的压强以及麦克斯韦分布率。下册内容包括电磁学、波动与光学、量子物理基础。电磁学篇按传统体系讲述了电场、电势、磁场、电磁感应和电磁波的基本概念和规律，还说明了电场和磁场的相对性。波动与光学篇介绍了振动与波的基本特征和光的干涉、衍射和偏振的基本规律。量子物理基础篇介绍了波粒二象性、概率波、不确定关系和能量量子化等基本概念以及原子和固体中电子的状态和分布的规律，还介绍了原子核的结合能、放射性衰变和核反应等基本知识。本书还编写了大量来自生活、实用技术以及自然现象等方面的例题和习题。本书上下册内容涵盖了大学物理学教学的基本要求，可作为高等院校物理课程的教材，也可作为中学物理教师或其他读者的自学参考书。与本书配套的《大学基础物理学学习辅导与习题解答（第3版）》、电子教案、教师用书（电子版）均由清华大学出版社出版。 ','理学'),(14,'高等代数（第五版）','王萼芳、石生明','/static/uploads/1671158654.395893.jpg','2019-05-01',44.6,'高等教育出版社','本书是第五版，基本上保持了第四版的内容，增加了几个应用例题，改写了矩阵的秩一节，补上了维特定理的证明，增加了附录四中有理标准形的内容，适当补充了数字资源。 本书主要内容是：多项式、行列式、线性方程组、矩阵、二次型、线性空间、线性变换、λ-矩阵、欧几里得空间、双线性函数与辛空间、总习题，附录包括关于连加号“∑”、整数的可除性理论、代数基本定理的证明、??-矩阵与矩阵相似标准形的几何理论。 本书适合作为高等学校数学类专业高等代数教材和教学参考书。','理学'),(15,'数字电子技术基础','范爱平、周常森','/static/uploads/1671096902.9836652.jpg','2008-05-01',39,'清华大学出版社','本书是山东大学山东省精品课程“电子技术基础”配套系列教材中的一本。主要内容参照了高等学校电子电气基础课程教学指导分委员会修订的数字电子技术基础课程教学基本要求，并融合了作者多年的教学经验及教学改革的体会。全书包括初识数字电路、分析与设计数字电路的工具、逻辑门电路、组合逻辑电路、记忆单元电路、时序逻辑电路、脉冲单元电路、半导体存储器、数模与模数转换器、可编程逻辑器件共10章。在内容安排上注意了由浅入深、循序渐进。在文字叙述上力求通俗易懂、生动有趣、层层展开，具有较强的可读性与可教性。为了便于多媒体教学，本书配有详实的电子课件。 本书主要作为高等院校电气、电子信息及自动化类专业的教材，也可供从事电子技术工作的有关人员和自学者参考。','工学'),(16,'模拟电子技术基础','王济浩','/static/uploads/1671122733.6120143.jpg','2009-03-01',39,'清华大学出版社','本书是山东省精品课程“电子技术基础”系列教材中的一本。它是按照 高等学校电子电气基础课程教学指导分委员会修订的模拟电子技术基础课程教学基本要求，融合作者多年的教学经验及教学改革的体会编写而成的。全书包括半导体器件、基本放大电路、运算放大器及其应用、负反馈放大器、正弦波和非正弦波信号发生器、功率放大器、稳压电源等内容。为了便于多媒体教学，本书配有翔实的电子课件。 本书主要作为高等院校电气工程、电子信息、计算机及自动化类专业的教材， 也可供从事电子技术工作的人员学习参考。','工学'),(17,'系统解剖学（第9版）','丁文龙、刘学政','/static/uploads/1671150133.6035583.jpg','2018-08-17',99,'人民卫生出版社','本套教材为全国高等学校五年制本科临床医学专业第九轮规划教材，是我国医学教育领域起步*早、历史*悠久、修订版次*多的权威、规范、科学、经典的*规划教材。第八轮教材自2013年秋季出版至今，已经4年时间，修订再版是学科知识及医学教育发展的需要。本次修订将根据医学教育发展的需要，注重课程体系的优化改革和教材体系建设的创新，并继续坚持\"三基、五性、三特定\"的教材编写原则，更新内容，体现继承与发展。','医学'),(18,'电力电子技术（第5版）','王兆安、刘进军','/static/uploads/1671171636.913089.jpg','2010-12-01',39,'机械工业出版社','《电力电子技术（第5版）》是在普通高等教育“九五”国家重点教材《电力电子技术》（第4版）（王兆安、黄俊主编，机械工业出版社，2000年出版，曾于2002年获国家教材一等奖）的基础上改编的，是“十一五”规划教材。本教材补充了内容，并对原有内容作了适当调整。内容括：各种电力电子器件、整流电路、逆变电路、直流变流电路、交流变流电路、PWM控制技术、软开关技术、电力电子器件应用的共性问题、电力电子技术的应用等。《电力电子技术（第5版）》对电力电子技术的内容进行了精选，体现了技术的发展。通过这次改版，全书结构更加合理，层次分明，更适合于大学本科教学。采用该书的西安交通大学“电力电子技术”课程是首批国家精品课程，课程网站有电子教案（课程网址：http：／／pel-course．xjtu．edu．cn），可供选用。书末附有教学实验。\r\n《电力电子技术（第5版）》适用于电气工程及其自动化专业、自动化专业以及工科引导性专业目录中的电气工程与自动化专业及其他相关专业的本科生，也可供相近专业选用或供工程技术人员参考。','工学'),(19,'电子技术实验-课程设计与仿真','姚福安、徐向华','/static/uploads/1671165304.4911196.jpg','2014-08-01',37.2,'清华大学出版社','本书是山东省精品课程“电子技术基础”配套系列教材之一，是参照教育部高等学校电子电气基础课程教学指导分委员会最新修订的电子技术基础实验教学的基本要求编写的，其内容融入了作者多年从事电子技术理论教学、电子技术实践教学及电子设计竞赛活动的教学经验及体会撰写而成。该教材突出了电子技术基础实践教学的系统性、实践性、创新性及探索性，将每个实验内容分成基础实验、提高实验及创新实验，以满足不同教学要求及教学对象的需要。全书共分为8章，主要内容为电子测量的基本知识、常用电子仪器的使用方法、电子电路的安装调试及测试技术、常用电子元器件及集成电路、模拟电子技术基础实验、数字电子技术基础实验、电子电路的计算机辅助分析与设计、电子技术基础课程设计。对于模拟电子技术基础和数字电子技术基础实验均增加了设计型实验项目，同时对每章、每个实验及课程设计单元均附有大量的习题、思考题。本书主要作为高等学校电气、电子信息及自动化专业电子技术实验和课程设计的教材使用，也可作为职业技术院校相关专业的电子技术实验、电子技术设计等课程的参考书，还可供电子设计竞赛培训、电子技术工程技术人员及电子爱好者使用。','工学'),(20,'Python程序设计基础与应用（第2版）','董付国','/static/uploads/1671170684.71419.jpg','2022-01-14',59.9,'机械工业出版社','本书是一本系统介绍Python程序开发与应用的教程，内容系统全面，配套资源丰富，应用性强。全书共13章，主要包括Python编程基础（第1～10章）和Python应用开发（第11～13章）两部分内容，编程基础部分通过众多案例对Python程序设计的相关概念加以解释，应用开发部分则介绍了网络爬虫、数据分析和数据可视化等方面的Python核心应用。本书全部代码适用于Python 3.6/3.7/3.8/3.9/3.10以及更高版本。\r\n本书可以作为非计算机专业研究生、本科、专科程序设计课程教材，也可作为计算机专业本、专科程序设计基础课程教材，以及Python爱好者自学用书。','信息学'),(21,'C++程序设计','谭浩强','/static/uploads/1671097826.9070497.jpg','2021-10-01',59.9,'清华大学出版社','C++是近年来国内外广泛使用的现代计算机语言。它既支持基于过程的程序设计，也支持面向对象的程序设计。国内许多高校开设了“C 程序设计”课程。但是，由于C++涉及概念很多，语法比较复杂，内容十分广泛，使不少人感到学习难度较大，难以入门。 作者深入调查了大学的程序设计课程的现状和发展趋势，参阅了国内外数十种有关C++的教材，认真分析了读者在学习中的困难和认识规律，设计了读者易于学习的教材体系，出版了《C++程序设计》一书。广大师生用后反映该书定位准确，概念清晰，深入浅出，取舍合理，以通俗易懂的语言对C 的许多难懂的概念做了透彻而通俗的说明，大大降低了初学者学习的困难，是初学者学习C 的优秀教材。 根据教学实践的需要，作者对《C++程序设计》进行了多次修订，现在出版《C++程序设计（第4版）》。本书从零起点介绍程序设计和C++，包括基于过程的程序设计、基于对象的程序设计和面向对象的程序设计。学习本书不需要C语言的基础，书中基于过程的程序设计部分涵盖了C语言程序设计的基本内容，因此本书实际上是一本C/C++教材，学习本书后既可以用C语言进行程序设计，也可以用C++进行程序设计。 为了便于教学，本书有《C++程序设计 （第4版）学习辅导》和《C++程序设计实践指导》两本配套教材，旨在帮助学生通过实践掌握C++的编程方法。 本书内容全面，例题丰富，循序渐进，易于学习，即使没有教师讲授，读者也能看懂书中的大部分内容。本书可供各专业学生使用，也可作为计算机培训班的教材以及自学教材。','信息学');
/*!40000 ALTER TABLE `myadmin_books` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `myadmin_types`
--

DROP TABLE IF EXISTS `myadmin_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `myadmin_types` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `myadmin_types`
--

LOCK TABLES `myadmin_types` WRITE;
/*!40000 ALTER TABLE `myadmin_types` DISABLE KEYS */;
INSERT INTO `myadmin_types` VALUES (1,'文学'),(2,'理学'),(3,'工学'),(4,'信息学'),(5,'医学'),(6,'农学'),(7,'艺术类'),(8,'体育类'),(9,'经管类');
/*!40000 ALTER TABLE `myadmin_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mylib_users`
--

DROP TABLE IF EXISTS `mylib_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mylib_users` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nickname` varchar(20) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `email` varchar(45) NOT NULL,
  `password` varchar(200) NOT NULL,
  `profile` varchar(100) NOT NULL,
  `address` varchar(100) DEFAULT NULL,
  `sex` varchar(2) DEFAULT NULL,
  `registerdate` date NOT NULL,
  `type` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mylib_users`
--

LOCK TABLES `mylib_users` WRITE;
/*!40000 ALTER TABLE `mylib_users` DISABLE KEYS */;
INSERT INTO `mylib_users` VALUES (1,'岳志邦','18753196806','yuezhibang@126.com','pbkdf2_sha256$390000$ZbvkcOLUSWfDgRcq0uSvZ4$FiGCTmSrhWblA7qx0UiHo0HIs1mFtQgngw0O9D8TGGM=','/static/uploads/1671060579.0375962.jpg','山东省济南市市中区福祥街','保密','2022-12-12','教育需要'),(2,'测试号1','11111111111','yuezhibang@126.com','pbkdf2_sha256$390000$TSnDlgWmsmaMgRpA8AZPD6$9IV9jMNcNHnAusomAewwLtyNNvovBQKC2XLZk5IuY/w=','/static/favicon.ico','保密2','男','2022-12-14','休闲娱乐'),(3,'测试号2','11111111112','yuezhibang@126.com','pbkdf2_sha256$390000$S1L7tFGMk4aZPUYnRbGpvJ$6HIOnW/XAaTGE9KJswaqvKk5L1OJmJcpkx5q0TDnmV4=','/static/favicon.ico','保密','女','2022-12-14','休闲娱乐'),(4,'测试号3','11111111113','yuezhibang@126.com','pbkdf2_sha256$390000$5jneRflLDH5zFateWvpAFz$Zu2bUjjr2QcBIr5qKI1mEk07GLpImJTaej6eRG9Tzqw=','/static/uploads/1671078929.181245.jpg','测试号3的家','男','2022-12-14','休闲娱乐'),(5,'测试号4','11111111114','yuezhibang@gmail.com','pbkdf2_sha256$390000$v274Qxwy8GXHy92xY2Xq60$0DdMo65XgvSCd5YK0k53TFZd4BZHwCXSa0DCJfR2aXs=','/static/favicon.ico','保密','男','2022-12-15','休闲娱乐'),(7,'测试号5','11111111115','yuezhibang@126.com','pbkdf2_sha256$390000$8u58i9cZ7NocZnsFzHicaE$PaTHZyDXV8QA81vsqp1Eg6pBIpZVHYSIP72oDI9JmJc=','/static/favicon.ico','','保密','2022-12-25','职业需要'),(8,'测试号8','11111111117','11111111117@admin.com','pbkdf2_sha256$390000$gMR6YzLUlK20Dqzpj7eJro$i4pObm/GjEWieD9ujGNKaPtbKTCZWsIgtRH+su260ys=','/static/uploads/1672737131.5596123.jpg','保密7','男','2023-01-03','休闲娱乐'),(9,'测试号9','11111111118','11111111118@admin.com','pbkdf2_sha256$390000$2Jgl4gLZZfkVt4FoyoUIGM$SAd+vgzY5o9rTA2QHj5FBLDPJ6N0cFAP8DNjhPmbizI=','/static/favicon.ico','保密8','女','2023-01-03','休闲娱乐'),(10,'测试号10','11111111119','11111111119@admin.com','pbkdf2_sha256$390000$9Z00Po3D00Nfw3jvjyUDU2$/LH8hk3XVrcLlT13KDU2YTnHLwe5vMIj8JgYTgUIjNk=','/static/favicon.ico','','保密','2023-01-03','休闲娱乐'),(11,'测试号11','11111111118','11111111118@admin.com','pbkdf2_sha256$390000$8qCDOeq2XAjq7KNOD8Dbap$ljt0AYo76bMQlXNYLWF5XDbH9HoqAvy0C0c5VqzHsw8=','/static/favicon.ico','保密','保密','2023-01-03','休闲娱乐');
/*!40000 ALTER TABLE `mylib_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'homework'
--

--
-- Dumping routines for database 'homework'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-01-03  9:47:44
